clear_console<-function(){
  cat("\14")
}
